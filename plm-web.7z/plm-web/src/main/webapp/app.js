(function() {
  var app = angular.module('plm', ['ui.router','ui.grid', 'ui.grid.selection']);
  
  app.run(function($rootScope, $location, $state, LoginService) {
    $rootScope.$on('$stateChangeStart', 
      function(event, toState, toParams, fromState, fromParams){ 
          console.log('Changed state to: ' + toState);
      });
    
      /*if(!LoginService.isAuthenticated()) {
        $state.transitionTo('login');
      }*/
  });
  
  app.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/login');
    
    $stateProvider
      .state('login', {
        url : '/login',
        templateUrl : 'login/login.html',
        controller : 'LoginController'
      })
      .state('home', {
        url : '/home',
        templateUrl : 'home/home.html',
        controller : 'HomeController'
      })
    .state('pricing', {
        url : '/pricing',
        templateUrl : 'Pricing/pricing.html',
        controller : 'PriceController'
      })
    .state('icoms', {
        url : '/icoms',
        templateUrl : 'Icoms/icoms.html',
        controller : 'IcomsController'
      })
    .state('operation', {
        url : '/operation',
        templateUrl : 'Operation/operation.html',
        controller : 'OperationController'
      });
  }]);

  app.controller('LoginController', function($scope, $rootScope, $stateParams, $state, $http,$location) {
	  
    $rootScope.title = "Login Page";
    
    $scope.formSubmit = function() {
    	
    /*  if(LoginService.login($scope.username, $scope.password,$http,$location)) {
    	  
        $scope.error = '';
        $scope.username = '';
        $scope.password = '';
        $state.transitionTo('home');
      } else {
        $scope.error = "Incorrect username/password !";
      } */ 
    	
    	var dataObj = {
    			"userName" : $scope.username,
    			"password" : $scope.password
		};
    	
    	 $http({
             method: 'POST',
             url: $location.protocol() + '://' + $location.host() + ':' + $location.port()  + '/plm-web/login/v0/users/authenticate',
             data: dataObj,
             headers: {
            	 'Content-Type': 'application/json'
             }
         })
           .then(function(response) {
        	   if(response.data === true){
               	$state.transitionTo('home');
               	}else{
               		$scope.error = "Incorrect username/password !";
               	}
               });/*,function (response) {
                   console.log(response); 
               });*/
    	
    };
    
  });
  
  
  app.controller('HomeController', function($scope, $rootScope, $stateParams, $state, LoginService,$http,$location) {
    $rootScope.title = "Marketing Home";
    
    $scope.creatnewSubmit= function(){
        //window.location = "#/pricing";
        
        var dataObj = {
        		
    		projectType : $scope.protyp,
    		projectName : $scope.projectname,
    		projectDesc : $scope.projectdesc,
    		projectStatus : $scope.prostat,
    		projectStartDt : $scope.startDate,
    		projectEndDt : $scope.endDate
 		};
        
     	 $http({
              method: 'POST',
              url: $location.protocol() + '://' + $location.host() + ':' + $location.port()  + '/plm-web/mktproject/v0/createNewProj',
              data: dataObj,
              headers: {
                  'Content-Type': 'application/json'
              }
          })
            .then(function successCallback(response) {
             	if(response.data!=null){
                	 $state.transitionTo('pricing');
                	/* $scope.gridOptions.data =response.data;
                	 $scope.gridApi.grid.refresh();*/
                	/* response.forEach( function( row, index ) {
                	        row.number = $scope.number;
                	        $scope.contacts.push(row);
                	    });
                	    $scope.gridOptions.data = response.data;
                	    console.log('data from contacts.json', response.data);*/
                	 //$scope.gridOptions.data = response.data;
                	 //$scope.gridApi.grid.refresh();
                	 //$scope.gridOptions.data = response;
                	/* $scope.gridOptions.data = [];
                     for (var i = 0; i < response.data.MktNewProjResp.length; i++) {
                         $scope.gridOptions.data.push(response.data.MktNewProjResp[i]);
                     }
                	 $scope.gridApi.grid.refresh();*/
                	}
                });
    };
    
    $scope.projecttype = ["Campaign", "Offer", "ICOMs Task"];
    $scope.projectStatus=["NEW", "PROCESS"];
    
  });
  
  
  app.controller('PriceController', function($scope, $rootScope, $stateParams, $state, LoginService,$http, $log, $timeout, uiGridConstants) {
           $rootScope.title = "Pricing Home";
           
           $scope.addSubmit= function(){
               window.location = "#/icoms";
           };
           
          $scope.gridOptions = {
                  enableRowSelection: true,
                  enableSelectAll: true,
                  selectionRowHeaderWidth: 25,
                  rowHeight: 25,
                 // showGridFooter:true
                };
               
                $scope.gridOptions.columnDefs = [
                  { name: 'Project Code' },
                  { name: 'Project Type'},
                  { name: 'Project Description' },
                  { name: 'Status' },
                  { name: 'Assigned To'},
                  { name: 'icon1', displayName: '',
                 cellTemplate: '<div class="ui-grid-cell-contents" title="{{COL_FIELD}}"><a ng-click = "" style="cursor: pointer;"><span class="fa fa-edit"></span> {{ COL_FIELD }}</a></div>'
                  },
                  
                  {name: 'icon2', displayName: '',
                      cellTemplate: '<div class="ui-grid-cell-contents" title="{{COL_FIELD}}"><a ng-click = "" style="cursor: pointer;"><span class="fa fa-eye"></span> {{ COL_FIELD }}</a></div>'
                  }
                  
                ];
               
                $scope.gridOptions.multiSelect = false;
               
               /* $http.get('Data/marketing.json')
                  .success(function(data) {
                    $scope.gridOptions.data = data;
                    $timeout(function() {
                      if($scope.gridApi.selection.selectRow){
                        $scope.gridApi.selection.selectRow($scope.gridOptions.data[0]);
                      }
                    });
                  });*/
                
                 $scope.gridOptions1 = {
                         enableRowSelection: true,
                         enableSelectAll: true,
                         selectionRowHeaderWidth: 25,
                         rowHeight: 25,
                        // showGridFooter:true
                       };
                      
                       $scope.gridOptions1.columnDefs = [
                         { name: 'Site Code' },
                         { name: 'Site Name'}
                        
                       ];
                      
                       $scope.gridOptions1.multiSelect = false;
                      
                       /*$http.get('Data/site.json')
                         .success(function(data) {
                           $scope.gridOptions1.data = data;
                           $timeout(function() {
                             if($scope.gridApi.selection.selectRow){
                               $scope.gridApi.selection.selectRow($scope.gridOptions1.data[0]);
                             }
                           });
                         });*/
                
           
         });

  
  app.controller('IcomsController', function($scope, $rootScope, $stateParams, $state, LoginService,$http, $log, $timeout, uiGridConstants) {
           $rootScope.title = "Icoms Home";
           
           $scope.oprSubmit= function(){
               window.location = "#/operation";

           };

           
           $scope.projecttype = ["Campaign", "Offer", "ICOMs Task"];
           $scope.projectStatus=["NEW", "PROCESS"];
           
           
           $scope.gridOptions = {
                  enableRowSelection: true,
                  enableSelectAll: true,
                  selectionRowHeaderWidth: 25,
                  rowHeight: 25,
                 // showGridFooter:true
                };
               
                $scope.gridOptions.columnDefs = [
                  { name: 'Project Code' },
                  { name: 'Project Type'},
                  { name: 'Project Description' },
                  { name: 'Status' },
                  { name: 'Assigned To'},
                  { name: 'icon1', displayName: ''},
                  {name: 'icon2', displayName: '',
                      cellTemplate: '<div class="ui-grid-cell-contents" title="{{COL_FIELD}}"><a ng-click = "" style="cursor: pointer;"><span class="fa fa-eye"></span> {{ COL_FIELD }}</a></div>'
                  }
                ];
               
                $scope.gridOptions.multiSelect = false;
               
                $http.get('Data/icoms.json')
                  .success(function(data) {
                    $scope.gridOptions.data = data;
                    $timeout(function() {
                      if($scope.gridApi.selection.selectRow){
                        $scope.gridApi.selection.selectRow($scope.gridOptions.data[0]);
                      }
                    });
                  });
           
  });
  
  
  app.controller('OperationController', function ($scope, $rootScope, $stateParams, $state, LoginService,$http, $log, $timeout, uiGridConstants) {
           $rootScope.title = "Operation Home";
                  
           $scope.gridOptions = {
                  enableRowSelection: true,
                  enableSelectAll: true,
                  selectionRowHeaderWidth: 25,
                  rowHeight: 25,
                 // showGridFooter:true
                };
               
                $scope.gridOptions.columnDefs = [
                  { name: 'Campaign ID' },
                  { name: 'PSU'},
                  { name: 'Campaign Name' },
                  { name: 'Campaign Description' },
                  { name: 'Campaign Start Date'},
                  { name: 'Campaign End Date'},
                  {name: 'Active' },
                  {name: 'Status' },
                  {name: 'Project Code' }
                ];
               
                $scope.gridOptions.multiSelect = false;
               
                $http.get('Data/operation.json')
                  .success(function(data) {
                    $scope.gridOptions.data = data;
                    $timeout(function() {
                      if($scope.gridApi.selection.selectRow){
                        $scope.gridApi.selection.selectRow($scope.gridOptions.data[0]);
                      }
                    });
                  });
           
         });
  
  app.factory('LoginService', function() {
    var admin = 'admin';
    var pass = 'pass';
    var isAuthenticated = false;
    
    return {
      login : function(username, password) {
        isAuthenticated = username === admin && password === pass;
        return isAuthenticated;
      },
      isAuthenticated : function() {
        return isAuthenticated;
      }
    };
    
    return {
        login : function(username, password,$http,$location) {
        	$http({
                method : 'POST',
                url: $location.protocol() + '://' + $location.host() + ':' + $location.port() + '/plm-web/login/v0/users/authenticate'
            }).then(function successCallback(response) {
            	isAuthenticated = (response.data === true)
            });
        },
        isAuthenticated : function() {
          return isAuthenticated;
        }
      };
    
  });
  
})();
