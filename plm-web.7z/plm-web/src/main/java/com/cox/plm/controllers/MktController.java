/**
 * 
 */
package com.cox.plm.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.task.TaskService;
import org.kie.api.task.model.TaskSummary;
import org.kie.internal.runtime.manager.context.ProcessInstanceIdContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cox.plm.mkt.request.MktNewProReq;
import com.cox.plm.mkt.response.MktNewProjResp;

/**
 * MktController for
 * 
 * @author Nitin
 *
 */
@RestController
@RequestMapping("/mktproject/v0")
public class MktController {

	@Autowired
	private RuntimeManager runtimeManager;

	@Autowired
	private TaskService taskService;

	@RequestMapping(value = "/createNewProj", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody MktNewProjResp validateLoginCredentials(@RequestBody MktNewProReq mktNewProReq) {

		System.out.println("Create New Project");
		RuntimeEngine engine = runtimeManager.getRuntimeEngine(ProcessInstanceIdContext.get());
		KieSession ksession = engine.getKieSession();
		taskService = engine.getTaskService();
		Map<String, Object> map = new HashMap<String, Object>();
		// let john execute Task 1
		List<TaskSummary> list = taskService.getTasksAssignedAsPotentialOwner("john", "en-UK");
		TaskSummary task = list.get(0);
		System.out.println("John is executing task " + task.getName());
		taskService.start(task.getId(), "john");
		taskService.complete(task.getId(), "john", null);

		// let mary execute Task 2
		list = taskService.getTasksAssignedAsPotentialOwner("mary", "en-UK");
		task = list.get(0);
		System.out.println("Mary is executing task " + task.getName());
		taskService.start(task.getId(), "mary");
		taskService.complete(task.getId(), "mary", null);

		runtimeManager.disposeRuntimeEngine(engine);
		System.exit(0);

		MktNewProjResp mktResp = new MktNewProjResp();
		mktResp.setProjectCode(mktNewProReq.getProjectCode());
		mktResp.setProjectName(mktNewProReq.getProjectName());
		mktResp.setProjectType(mktNewProReq.getProjectType());
		mktResp.setProjectDesc(mktNewProReq.getProjectDesc());
		mktResp.setProjectInfo(mktNewProReq.getProjectInfo());
		mktResp.setProjectStartDt(mktNewProReq.getProjectStartDt());
		mktResp.setProjectEndDt(mktNewProReq.getProjectEndDt());

		return mktResp;
	}
}