package com.cox.plm.common.util;

import java.net.UnknownHostException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public final class StringUtils {

    private StringUtils() {

    }

    public static String toString(Object obj) {
        return ReflectionToStringBuilder.toString(obj, ToStringStyle.MULTI_LINE_STYLE);
    }

    public static boolean isEmpty(String input) {
        return (null == input) || "".equals(input) || "".equals(input.trim()) ? true : false;
    }

    public static boolean areAllEmpty(String... input) {

        if ((input == null) || (input.length < 1))
            return true;

        for (String oneInput : input) {
            if ((oneInput != null) && (!"".equals(oneInput)) && (!"".equals(oneInput.trim())))
                return false;
        }
        return true;
    }

    public static boolean areAnyEmpty(String... input) {

        if ((input == null) || (input.length < 1))
            return true;

        for (String oneInput : input) {
            if ((oneInput == null) || ("".equals(oneInput)) || ("".equals(oneInput.trim())))
                return true;
        }
        return false;
    }

    public static boolean isValidEmailAddress(String emailAddress) {
        String expression = "^[\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = emailAddress;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }

    public static boolean isValidPassword(String password) {
        String expression = "^[A-Za-z][A-Za-z0-9_!@#$%()-]{4,}$";
        CharSequence inputStr = password;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }

    public static boolean isNumeric(String input) {
        String expression = "^[0-9]*";
        CharSequence inputStr = input;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }

    public static boolean isAlphaNumeric(String input) {
        String expression = "^[a-zA-Z0-9]*";
        CharSequence inputStr = input;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }

    public static boolean isAlpha(String input) {
        String expression = "^[a-zA-Z]*";
        CharSequence inputStr = input;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }

    public static String toLower(final String input) {

        if (StringUtils.isEmpty(input))
            return null;

        return input.toLowerCase();
    }

    public static String getTenDigitTN(String telePhoneNo) {
        if (telePhoneNo == null) {
            return null;
        }
        String tn = telePhoneNo.trim();
        StringBuilder sbf = new StringBuilder();
        for (int i = 0; i < tn.length(); i++) {
            char c = tn.charAt(i);
            if (c >= '0' && c <= '9') {
                sbf.append(c);
            }
        }
        return sbf.toString();
    }

    public static boolean checkLength(String input, int len) {
        return (input.length() > len) ? false : true;
    }

    // Revert the * added by FR_CR_26 in DAPS
    public static String covert2AlphaNumeric(String s) {
        String str = s;
        String temp = "";
        if ((s != null) && (s.length() > 3) && ("Mc*".equalsIgnoreCase(s.substring(0, 3)))) {
            temp = s.substring(3);
            return "Mc" + temp;
        } else {
            return str;
        }
    }

    public static String getHostInfo() {
        StringBuilder sb = new StringBuilder(25);

        sb.append("[ ip: ");
        try {
            sb.append(java.net.InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            sb.append("UNKNOWN");

        }
        sb.append(" host: ");
        try {
            sb.append(java.net.InetAddress.getLocalHost().getCanonicalHostName()).append(" ]");
        } catch (UnknownHostException e) {
            sb.append("UNKNOWN ]");
        }

        return sb.toString();
    }

}