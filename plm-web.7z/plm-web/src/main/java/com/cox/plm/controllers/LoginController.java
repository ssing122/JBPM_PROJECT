/**
 * 
 */
package com.cox.plm.controllers;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cox.plm.common.util.StringUtils;
import com.cox.plm.login.request.LoginRequest;

/**
 * LoginController for 
 * 
 * @author Nitin
 *
 */
@RestController
@RequestMapping(value = "/login/v0")
public class LoginController {
	
	private static final Logger LOG = Logger.getLogger(LoginController.class);
	
	
	@RequestMapping(value = "/users/authenticate", method = RequestMethod.POST)
    public boolean validateLoginCredentials(@RequestBody LoginRequest loginReq) {
		
		LOG.info("LoginController - LoginIn");
		
		try {
			
			if(StringUtils.isEmpty(loginReq.getUserName()) || StringUtils.isEmpty(loginReq.getPassword())){
				LOG.info("LoginController - Invalid Login");
				return false;
			}else if("admin".equals(loginReq.getUserName()) && "pass".equals(loginReq.getPassword())){
				LOG.info("LoginController - Valid Login");
				
				return true;
			}else{
				LOG.info("LoginController - Invalid Login");
				return false;
			}
			
		} catch (Exception e) {
			LOG.error("LoginController - Invalid Login",e);
		}	
		return true;
	}	
}