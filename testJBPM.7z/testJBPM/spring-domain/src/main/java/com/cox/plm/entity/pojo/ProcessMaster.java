/**
 * 
 */
package com.cox.plm.entity.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author nchoube
 *
 */
@Entity
@Table(name = "PROCESS_MASTER", schema = "PLMDB")
public class ProcessMaster implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -1546286330814534759L;

	@Id
	@Column(name = "PROJECT_ID")
	@GeneratedValue
	private String projectId;

	@Column(name = "PROCESS_NAME")
	private String processName;

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}
	
}
