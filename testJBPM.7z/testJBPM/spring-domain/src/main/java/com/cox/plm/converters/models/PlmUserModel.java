/**
 * 
 */
package com.cox.plm.converters.models;

import java.io.Serializable;

/**
 * @author nchoube
 *
 */
public class PlmUserModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3486017841165843823L;

	private String userId;
	private String firstname;
	private String lastName;
	private UserRoleModel roleId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public UserRoleModel getRoleId() {
		return roleId;
	}

	public void setRoleId(UserRoleModel roleId) {
		this.roleId = roleId;
	}
}
