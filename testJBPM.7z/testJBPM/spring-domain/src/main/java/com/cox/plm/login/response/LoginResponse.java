/**
 * 
 */
package com.cox.plm.login.response;

import java.io.Serializable;

import com.cox.plm.common.response.BaseResponse;

/**
 * @author nchoube
 *
 */
public class LoginResponse extends BaseResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 26362218868061110L;
	
	private String userName;
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
