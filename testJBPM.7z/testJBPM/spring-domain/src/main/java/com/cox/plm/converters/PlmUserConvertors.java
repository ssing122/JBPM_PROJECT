/**
 * 
 */
package com.cox.plm.converters;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.cox.plm.common.converter.Converter;
import com.cox.plm.converters.models.PlmUserModel;
import com.cox.plm.converters.models.UserRoleModel;
import com.cox.plm.entity.pojo.PlmUser;
import com.cox.plm.entity.pojo.UserRole;

/**
 * @author nchoube
 *
 */
@Component
@Qualifier("plmUserConvertors")
public class PlmUserConvertors implements Converter<PlmUser, PlmUserModel>{

	@Override
	public PlmUser getSource(PlmUserModel target) {
		
		PlmUser source = new PlmUser();
		source.setUserId(target.getUserId());
		source.setFirstname(target.getFirstname());
		source.setLastName(target.getLastName());
		
		UserRole role = new UserRole();
		role.setRoleId(target.getRoleId().getRoleId());
		role.setRoleName(target.getRoleId().getRoleName());
		role.setDesc(target.getRoleId().getDesc());
		source.setRoleId(role);
		return source;
	}

	@Override
	public PlmUserModel getTarget(PlmUser source) {
		
		PlmUserModel target = new PlmUserModel();
		target.setUserId(source.getUserId());
		target.setFirstname(source.getFirstname());
		target.setLastName(source.getLastName());
		
		UserRoleModel roleModel = new UserRoleModel();
		roleModel.setRoleId(source.getRoleId().getRoleId());
		roleModel.setRoleName(source.getRoleId().getRoleName());
		roleModel.setDesc(source.getRoleId().getDesc());
		target.setRoleId(roleModel);
		return target;
	}

}
