/**
 * 
 */
package com.cox.plm.converters.models;

import java.util.HashSet;
import java.util.Set;

/**
 * @author nchoube
 *
 */

public class UserRoleModel implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1139017292773807550L;

	private String roleId;
	private String roleName;
	private String desc;
	private Set<PlmUserModel> plmUser = new HashSet<PlmUserModel>(0);

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Set<PlmUserModel> getPlmUser() {
		return plmUser;
	}

	public void setPlmUser(Set<PlmUserModel> plmUser) {
		this.plmUser = plmUser;
	}

}
