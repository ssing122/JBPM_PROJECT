/**
 * 
 */
package com.cox.plm.mkt.request;

import java.io.Serializable;

/**
 * @author nchoube
 *
 */
public class MktNewProReq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6693236646444721563L;
	
	private String projectCode;
	private String projectType;
	private String projectName;
	private String projectDesc;
	private String projectStatus;
	private String projectStartDt;
	private String projectEndDt;
	private String projectInfo;
	private String requestDoc;
	
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectDesc() {
		return projectDesc;
	}
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	public String getProjectStatus() {
		return projectStatus;
	}
	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}
	public String getProjectStartDt() {
		return projectStartDt;
	}
	public void setProjectStartDt(String projectStartDt) {
		this.projectStartDt = projectStartDt;
	}
	public String getProjectEndDt() {
		return projectEndDt;
	}
	public void setProjectEndDt(String projectEndDt) {
		this.projectEndDt = projectEndDt;
	}
	public String getProjectInfo() {
		return projectInfo;
	}
	public void setProjectInfo(String projectInfo) {
		this.projectInfo = projectInfo;
	}
	public String getRequestDoc() {
		return requestDoc;
	}
	public void setRequestDoc(String requestDoc) {
		this.requestDoc = requestDoc;
	}

}