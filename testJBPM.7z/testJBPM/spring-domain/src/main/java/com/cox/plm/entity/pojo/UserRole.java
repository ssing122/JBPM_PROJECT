/**
 * 
 */
package com.cox.plm.entity.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author nchoube
 *
 */
@Entity
@Table(name = "USER_ROLE",schema="PLMDB")
public class UserRole implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4750458092103134371L;

	@Id
	@GeneratedValue
	@Column(name = "ROLE_ID")
	private String roleId;

	@Column(name = "ROLE_NAME", unique = true, nullable = false, length = 100)
	private String roleName;

	@Column(name = "DESCRIPTION", unique = true, nullable = false, length = 100)
	private String desc;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "roleId")
	private Set<PlmUser> plmUser = new HashSet<PlmUser>(0);
	
	
	public UserRole() {
	}

	public UserRole(String roleId) {
		this.roleId = roleId;
	}

	public UserRole(String roleId, String roleName, String desc, Set<PlmUser> plmUser) {
		this.roleId = roleId;
		this.roleName = roleName;
		this.desc = desc;
		this.plmUser = plmUser;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Set<PlmUser> getPlmUser() {
		return plmUser;
	}

	public void setPlmUser(Set<PlmUser> plmUser) {
		this.plmUser = plmUser;
	}
}
