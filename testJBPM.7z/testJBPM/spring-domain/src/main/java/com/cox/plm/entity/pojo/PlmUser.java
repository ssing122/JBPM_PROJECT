/**
 * 
 */
package com.cox.plm.entity.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author nchoube
 *
 */
@Entity
@Table(name = "PLM_USER",schema="PLMDB")
public class PlmUser implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7922736251976254238L;

	@Id
	@GeneratedValue
	@Column(name = "USER_ID")
	private String userId;

	@Column(name = "FIRST_NAME", unique = true, nullable = false, length = 100)
	private String firstname;

	@Column(name = "LAST_NAME", unique = true, nullable = false, length = 100)
	private String lastName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", nullable = false)
	private UserRole roleId;
	
	public PlmUser() {
	}

	public PlmUser(String userId) {
		this.userId = userId;
	}

	public PlmUser(String userId, String firstname, String lastName, UserRole roleId) {
		this.userId = userId;
		this.firstname = firstname;
		this.lastName = lastName;
		this.roleId = roleId;
	}
	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public UserRole getRoleId() {
		return roleId;
	}

	public void setRoleId(UserRole roleId) {
		this.roleId = roleId;
	}

}
