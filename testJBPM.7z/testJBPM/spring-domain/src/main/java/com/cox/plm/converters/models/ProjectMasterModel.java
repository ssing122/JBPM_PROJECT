/**
 * 
 */
package com.cox.plm.converters.models;

import java.io.Serializable;

/**
 * @author nchoube
 *
 */
public class ProjectMasterModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7706207790315674969L;
	
	private String projectId;
	private String projectCode;
	private String projectType;
	private String projectName;
	private String projectDesc;
	private String projectStartDt;
	private String projectEndDt;
	
	
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectDesc() {
		return projectDesc;
	}
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	public String getProjectStartDt() {
		return projectStartDt;
	}
	public void setProjectStartDt(String projectStartDt) {
		this.projectStartDt = projectStartDt;
	}
	public String getProjectEndDt() {
		return projectEndDt;
	}
	public void setProjectEndDt(String projectEndDt) {
		this.projectEndDt = projectEndDt;
	}
	
}
