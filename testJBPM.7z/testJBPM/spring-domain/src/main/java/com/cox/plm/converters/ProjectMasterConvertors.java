/**
 * 
 */
package com.cox.plm.converters;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.cox.plm.common.converter.Converter;
import com.cox.plm.common.util.DateUtil;
import com.cox.plm.converters.models.ProjectMasterModel;
import com.cox.plm.entity.pojo.ProjectMaster;

/**
 * @author nchoube
 *
 */
@Component
@Qualifier("projectMasterConvertors")
public class ProjectMasterConvertors implements Converter<ProjectMaster, ProjectMasterModel>{

	@Override
	public ProjectMaster getSource(ProjectMasterModel target) {
		
		ProjectMaster source = new ProjectMaster();
		source.setProjectId(target.getProjectId());
		source.setProjectCode(target.getProjectCode());
		source.setProjectName(target.getProjectName());
		source.setProjectType(target.getProjectType());
		source.setProjectDesc(target.getProjectDesc());
				
		if(!Objects.isNull(target.getProjectStartDt())){
		source.setProjectStartDt(DateUtil.convertStringToDate(target.getProjectStartDt()));
		}
		if(!Objects.isNull(target.getProjectEndDt())){
			source.setProjectEndDt(DateUtil.convertStringToDate(target.getProjectEndDt()));
		}
		return source;
	}

	@Override
	public ProjectMasterModel getTarget(ProjectMaster source) {
		
		ProjectMasterModel target = new ProjectMasterModel();
		target.setProjectId(source.getProjectId());
		target.setProjectCode(source.getProjectCode());
		target.setProjectName(source.getProjectName());
		target.setProjectType(source.getProjectType());
		target.setProjectDesc(source.getProjectDesc());
		
		if(!Objects.isNull(source.getProjectStartDt())){
			target.setProjectStartDt(DateUtil.getGMTString(source.getProjectStartDt()));
		}
		if(!Objects.isNull(source.getProjectEndDt())){
			target.setProjectEndDt(DateUtil.getGMTString(source.getProjectEndDt()));
		}
		return target;
	}

}
