/**
 * 
 */
package com.cox.plm.entity.pojo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author nchoube
 *
 */
@Entity
@Table(name = "PROJECT_MASTER", schema = "PLMDB")
@NamedQueries({
    @NamedQuery(name = "ProjectMaster.ALLPROJECT", query = "FROM ProjectMaster")
})
public class ProjectMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -221729696026370965L;

	@Id
	@Column(name = "PROJECT_ID")
	@GeneratedValue
	private String projectId;

	@Column(name = "PROJECT_CODE")
	private String projectCode;

	@Column(name = "PROJECT_TYPE")
	private String projectType;

	@Column(name = "PROJECT_NAME")
	private String projectName;

	@Column(name = "PROJECT_DESC")
	private String projectDesc;

	@Column(name = "PROJECT_START_DATE")
	private Date projectStartDt;

	@Column(name = "PROJECT_END_DATE")
	private Date projectEndDt;

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDesc() {
		return projectDesc;
	}

	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}

	public Date getProjectStartDt() {
		return projectStartDt;
	}

	public void setProjectStartDt(Date projectStartDt) {
		this.projectStartDt = projectStartDt;
	}

	public Date getProjectEndDt() {
		return projectEndDt;
	}

	public void setProjectEndDt(Date projectEndDt) {
		this.projectEndDt = projectEndDt;
	}

}
