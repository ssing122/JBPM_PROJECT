/**
 * 
 */
package com.cox.plm.entity.pojo;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author nchoube
 *
 */
@Entity
@Table(name = "PROCESS_ADMIN",schema="PLMDB")
public class ProcessAdmin implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8763258226171416379L;
	
	@Id
	@Column(name = "PROCESS_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String processId;  
	
	@Column(name = "USER_ID")
	private String userId;
	
	@Column(name = "CREATED_DATE")
	private Date createdDate; 

}
