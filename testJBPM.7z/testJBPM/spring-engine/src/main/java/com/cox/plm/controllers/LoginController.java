/**
 * 
 */
package com.cox.plm.controllers;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cox.plm.common.util.CommonValidation;
import com.cox.plm.login.dao.services.PlmUserDAOServiceIntf;
import com.cox.plm.login.request.LoginRequest;
import com.cox.plm.login.response.LoginResponse;

/**
 * LoginController for 
 * 
 * @author Nitin
 *
 */
@RestController
@RequestMapping(value = "/login/v0")
public class LoginController {
	
	private static final Logger LOG = Logger.getLogger(LoginController.class);
	
	@Autowired
	private PlmUserDAOServiceIntf plmUserDAOServices;
	
	@RequestMapping(value = "/users/authenticate", method = RequestMethod.POST)
    public boolean validateLoginCredentials(@RequestBody LoginRequest loginReq) {
		
		LOG.info("LoginController - LoginIn");
		
		try {
			
			if(CommonValidation.validateInputLoginIn(loginReq.getUserName(),loginReq.getPassword())){
				LOG.debug("LoginController - Valid Login");
				LoginResponse response = plmUserDAOServices.validateLoginInUser(loginReq);
				return true;
			}else{
				LOG.debug("LoginController - Invalid Login");
			}
			
		} catch (Exception e) {
			LOG.error("LoginController - Invalid Login",e);
		}	
		return true;
	}	
}