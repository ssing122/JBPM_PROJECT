/**
 * 
 */
package com.cox.plm.controllers;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cox.plm.common.util.Constants;
import com.cox.plm.mkt.dao.services.MktDAOServiceIntf;
import com.cox.plm.mkt.request.MktNewProReq;
import com.cox.plm.mkt.response.MktNewProjResp;

/**
 * MktController for
 * 
 * @author Nitin
 *
 */
@RestController
@RequestMapping("/mktproject/v0")
public class MktController {

	private static final Logger LOG = Logger.getLogger(MktController.class);
	
	@Autowired
	private MktDAOServiceIntf mktDAOServiceIntf;

	@RequestMapping(value = "/createNewProj", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody MktNewProjResp createNewPro(@RequestBody MktNewProReq mktNewProReq) {

		LOG.info("MktController - Create New Project");
		MktNewProjResp mktResp = new MktNewProjResp();

		try {

			mktResp.setProjectCode(mktNewProReq.getProjectCode());
			mktResp.setProjectName(mktNewProReq.getProjectName());
			mktResp.setProjectType(mktNewProReq.getProjectType());
			mktResp.setProjectDesc(mktNewProReq.getProjectDesc());
			mktResp.setProjectInfo(mktNewProReq.getProjectInfo());
			mktResp.setProjectStartDt(mktNewProReq.getProjectStartDt());
			mktResp.setProjectEndDt(mktNewProReq.getProjectEndDt());
			
			mktResp =  mktDAOServiceIntf.createProject(mktNewProReq);

		} catch (Exception e) {
			LOG.error("MktController - Exception:", e);
			mktResp.setActionStatus(Constants.STATUS_FAIL);
		}
		//List<MktNewProjResp> mktRespList = fetchAllProjects();
		return mktResp;
	}
	
	@RequestMapping(value = "/fetchAllProj", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<MktNewProjResp> fetchAllProjects() {

		LOG.info("MktController - Create New Project");
		List<MktNewProjResp> mktResp = new ArrayList<MktNewProjResp>();

		try {

			mktResp =  mktDAOServiceIntf.fetchAllProjects();

		} catch (Exception e) {
			LOG.error("MktController - Exception:", e);
		}

		return mktResp;
	}
	
	/*private List<MktNewProjResp> fetchAllProjects() {

		LOG.info("MktController - Create New Project");
		List<MktNewProjResp> mktResp = new ArrayList<MktNewProjResp>();

		try {

			mktResp =  mktDAOServiceIntf.fetchAllProjects();

		} catch (Exception e) {
			LOG.error("MktController - Exception:", e);
		}

		return mktResp;
	}*/
}