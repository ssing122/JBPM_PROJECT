PLM_PROJECT='/plm-engine/mktproject/v0/fetchAllProj'
PLM_LOGIN='/plm-engine/login/v0/users/authenticate'
PLM_MARKETING='/plm-engine/mktproject/v0/createNewProj'