package com.cox.plm.common.response;

import java.io.Serializable;

public class BaseResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2552170885201849271L;
	private ActionResult actionResult ;
	private String actionStatus;
	
	
	public ActionResult getActionResult() {
		return actionResult;
	}
	public void setActionResult(ActionResult actionResult) {
		this.actionResult = actionResult;
	}
	public String getActionStatus() {
		return actionStatus;
	}
	public void setActionStatus(String status) {
		this.actionStatus = status;
	}
	
}
