package com.cox.plm.common.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class DateUtil  {

	private static Logger log = LogManager.getLogger(DateUtil.class.getName());

	private DateUtil(){
		
	}
	private static final DateFormat yyyyMMdd_FORMATTER = new SimpleDateFormat("yyyyMMdd");
	private static final DateFormat DATE_YEAR_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");

	private static final DateFormat DATE_TIME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static Date createTime(Date date, int hour, int minute){
        Calendar cal = new GregorianCalendar();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        return cal.getTime();
    }

    public static int getHour(Date date){
        Calendar cal = new GregorianCalendar();
        cal.setTime(date);
        return cal.get(Calendar.HOUR_OF_DAY);
    }

    public static int getMinutes(Date date){
        Calendar cal = new GregorianCalendar();
        cal.setTime(date);
        return cal.get(Calendar.MINUTE);
    }


    public static long diffInHours(Calendar cal1, Calendar cal2){
        return diffInMill(cal1, cal2) / (60 * 60 * 1000);
    }

     public static long diffInHours(Date a, Date b){
        Calendar cal1 =new GregorianCalendar();
        cal1.setTime(a);
        Calendar cal2 =new GregorianCalendar();
        cal2.setTime(b);
        return diffInHours(cal1, cal2);
    }


    public static long diffInDays(Date a, Date b){
        return diffInMill(a, b) / (24 * 60 * 60 * 1000);
    }

    public static long diffInDays(Calendar cal1, Calendar cal2){
        return diffInMill(cal1, cal2) / (24 * 60 * 60 * 1000);
    }

    public static long diffInMill(Date a, Date b){
        Calendar cal1 =new GregorianCalendar();
        cal1.setTime(a);
        Calendar cal2 =new GregorianCalendar();
        cal2.setTime(b);
        return diffInMill(cal1, cal2);
    }

    public static long diffInMill(Calendar cal1, Calendar cal2) {
        long diff;
        if(cal2.after(cal1)){
            diff = cal2.getTimeInMillis() - cal1.getTimeInMillis();
        }
        else {
            diff = cal1.getTimeInMillis() - cal2.getTimeInMillis();
        }
        return diff;
    }

    public static Date createBeginOfDay() {
        Calendar cal = new GregorianCalendar();
        cal.setTime(new Date());

        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return cal.getTime();
    }
    static int hourOFDAY=24;
    public static Date createEndOfDay() {
        Calendar cal = new GregorianCalendar();
        cal.setTime(new Date());

        cal.set(Calendar.HOUR_OF_DAY, hourOFDAY);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 0);

        return cal.getTime();
    }

    public static TimeZone getTimeZone(){
        return TimeZone.getTimeZone("GMT");
    }

    public static String convertGMTToEastern(String gmtDateStr, String sourceDtFormat, String targetDtFormat){
        Date gmtDate = null;
        String easternDate = null;
        if(gmtDateStr !=null && gmtDateStr.trim().length()>0){
            try {
                DateFormat estdatedformat = new SimpleDateFormat(targetDtFormat);
                DateFormat gmtdatedformat = new SimpleDateFormat(sourceDtFormat);
                estdatedformat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
                gmtdatedformat.setTimeZone(TimeZone.getTimeZone("GMT"));
                 gmtDate = gmtdatedformat.parse(gmtDateStr);
                 easternDate = estdatedformat.format(gmtDate);
            } catch (ParseException e) {
            	log.error(e);
            }
        }
        return easternDate;
    }

    public static Date getDateTime() {
        Date date = null;
        java.util.Date dt = new java.util.Date ();
        String dateStr = DATE_TIME.format (dt);
        try{
             date = DATE_TIME.parse (dateStr);
        }
        catch(ParseException pe){
        	log.error(pe);
        }

        return date;
    }

    public static Date getGMTDate(Date date){
        Date dte = null;
        try{
        	DATE_TIME.setTimeZone(TimeZone.getTimeZone("GMT"));

        String dt = DATE_TIME.format(date);
        dte = DATE_TIME.parse(dt);

        }catch(Exception e){
        	log.error(e);
        }
         return dte;
    }
    
    public static String getGMTString(Date date){
    	
        String dte = null;
        
        try{
        	
        	DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
            df.setTimeZone(TimeZone.getTimeZone("GMT"));
            dte = df.format(date);

        }catch(Exception e){
        	log.error(e);
        }
         return dte;
    }
    
    public static XMLGregorianCalendar dateToXMLGregorianCalendar(java.util.Date date) {
        try {
            if (date == null) {
                return null;
            } else {
                GregorianCalendar gc = new GregorianCalendar();
                gc.setTime(date);
                return DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
            }
        } catch (Exception thr)  {
        	log.error(thr);
        }
        return null;
    }


    public static java.util.Date xMLGregorianCalendarToDate(XMLGregorianCalendar xgc) {
        if (xgc == null) {
            return null;
        } else {
            return xgc.toGregorianCalendar().getTime();
        }
    }

    public static Date addOneDay(Date date) {
        Calendar cal = new GregorianCalendar();
        cal.setTime(date);

        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 0);

        return cal.getTime();
    }
	
	public static Date beginOfDay() {
        Calendar cal = new GregorianCalendar();
        cal.setTime(new Date());

        cal.set(Calendar.HOUR_OF_DAY, 00);
        cal.set(Calendar.MINUTE, 00);
        cal.set(Calendar.SECOND, 00);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
	public static Date parse(String dateValue) throws ParseException {
		return DATE_YEAR_FORMATTER.parse(dateValue);
	}

	public static String format(Date dateValue) {
		return DATE_YEAR_FORMATTER.format(dateValue);
	}
	
	public static Date parseTime(String dateValue) throws ParseException {
		return DATE_TIME.parse(dateValue);
	}

	public static String formatTime(Date dateValue) {
		return DATE_TIME.format(dateValue);
	}

	public static String formatyyyyMMdd(Date date) {
		return yyyyMMdd_FORMATTER.format(date);
	}
	
    public static Timestamp convertStringToTimestamp(String date) throws ParseException {

        DateFormat targetFormat = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSSSSSSSS a");
        DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dt = originalFormat.parse(date);
        String formattedDate = targetFormat.format(dt);
        Date dts = targetFormat.parse(formattedDate);
        return new Timestamp(dts.getTime());
    }
    
    /**
     * This method used for DAPS dates
     * @param xc
     * @return
     */
    public static String convertXmlGregorianToString(XMLGregorianCalendar xc)
    {
        GregorianCalendar gCalendar = xc.toGregorianCalendar();
         
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm a z");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
         
        String dateString = df.format(gCalendar.getTime());
        return dateString;
    }
    
    /**
     * This method used for DAPS dates
     * @param xc
     * @return
     */
    public static Date convertGregorianStringToDate(String cal) 
    {
    	Date date=null;
    	try {
    		  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
    		  date =dateFormat.parse(cal);
		} catch (ParseException e) {
			log.error("Exception in parsing date ",e);
		}
    	return date;
    }  
    
    public static Date convertStringToDate(String cal) 
    {
    	Date date=null;
    	try {
    		  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
    		  date =dateFormat.parse(cal);
		} catch (ParseException e) {
			log.error("Exception in parsing date ",e);
		}
    	return date;
    }  

}