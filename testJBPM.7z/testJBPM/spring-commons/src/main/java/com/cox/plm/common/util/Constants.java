/**
 * 
 */
package com.cox.plm.common.util;

/**
 * @author nchoube
 *
 */
public class Constants {
	
	/**
	 * Common constants
	 */
	
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAIL = "FAIL";
	public static final int LEN_100 = 100;
	public static final int LEN_50 = 50;
	public static final int LEN_10 = 10;
	public static final String ERROR_INTERNAL_SERVER = "ERROR_INTERNAL_SERVER";
	
	/**
	 * Marketing Constants
	 */
	public static final String PROCESS_ID_MARKETING = "PRO101";
	public static final String PROJECT_CODE_MARKETING = "GTM2B2017_1";
	
	/*
	 * Messages constants
	 */
	public static final String MESSAGE_PROPERTIES="message.properties";
	public static final String MSG_INVALID_LOGIN="MSG_INVALID_LOGIN_INFO";
}
