package com.cox.plm.common.response;
import java.io.Serializable;

public class ActionWarning implements Serializable {
    
	/**
	 * 
	 */
	private static final long serialVersionUID = -2661485228837333716L;
	private  String type;
    private  String description;
    
    public ActionWarning(){
    	
    }
	public ActionWarning(String type, String description) {
        this.type = type;
        this.description = description;
	}

    public String getType() {
        return type;
    }
    
    public String getDescription() {
        return description;
    }
    
    @Override
    public String toString() {
    	return "ActionWarning["+type+",'"+description+"']";
    }
	public void setType(String type) {
		this.type = type;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
