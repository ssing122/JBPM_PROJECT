/**
 * 
 */
package com.cox.plm.common.message.handler;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Objects;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cox.plm.common.util.Constants;

/**
 * @author nchoube
 *
 */
public class MessageHandler implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3759451961948590567L;
	private static final Logger LOG = Logger.getLogger(MessageHandler.class);
	private Properties params = new Properties();

	private MessageHandler() {

		InputStream is = this.getClass().getClassLoader().getResourceAsStream(Constants.MESSAGE_PROPERTIES);
		if (!Objects.isNull(is)) {
			try {
				params.load(is);
			} catch (Exception e) {
				LOG.error(e);
				try {
					throw new IOException(e.getMessage());
				} catch (IOException e1) {
					LOG.error("MessageHandler - Exception while loading file", e1);
				}
			} finally {
				if (!Objects.isNull(is)) {
					try {
						is.close();
					} catch (IOException e) {
						LOG.error("MessageHandler - Exception while loading file", e);
					}
				}
			}
		} else {
			LOG.info("MessageHandler - Exception unable to load file" + Constants.MESSAGE_PROPERTIES
					+ " Not Found in CLASSPATH");
		}
	}

	private static class MessageHandlerHelper {
		private static final MessageHandler instance = new MessageHandler();
	}

	public static MessageHandler getInstance() {
		return MessageHandlerHelper.instance;
	}

	protected Object readResolve() {
		return getInstance();
	}

	protected Object clone() {
		return new CloneNotSupportedException("Cloning is not allowed");
	}
	
	public String getParameter(String key, String defaultvalue) {
        return params.getProperty(key, defaultvalue);
    }
}
