package com.cox.plm.common.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ActionResult implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 6631693708025189858L;
	private List<ActionError>	errors		= null;
	private List<ActionWarning>	warnings	= null;

	public ActionResult() {
		errors = new ArrayList<>();
		warnings = new ArrayList<>();
	}


	public void addError(ActionError error) {
		errors.add(error);
	}

	/**
	 * Convenience method for conditionally creating and adding an error.
	 * 
	 * @return the condition, for convenience
	 */
	public boolean addError(boolean condition, String type, String message) {
		if (condition) {
			this.addError(new ActionError(type, message));
			return true;
		}
		return false;
	}

	/**
	 * Convenience method for setting the form-level generic error.
	 */
	public void setError(String message) {
		this.addError(new ActionError(message));
	}

	public void addWarning(ActionWarning warning){
		warnings.add(warning);
	}
	
	public boolean addWarning(boolean condition, String type, String message) {
		if(condition){
			this.addWarning(new ActionWarning(type, message));
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "ActionResult[ERRORS: " + this.errors + "][WARNINGS: " + this.warnings +"]";
	}
	
	public void setErrors(List<ActionError> errors) {
		this.errors = errors;
	}

	public void setWarnings(List<ActionWarning> warnings) {
		this.warnings = warnings;
	}

	public List<ActionError> getErrors() {
		return errors;
	}
	public List<ActionWarning> getWarnings() {
		return warnings;
	}
}
