package com.cox.plm.common.converter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public interface Converter<S,T> {
	
	public S getSource(final T target);
	
	public T getTarget(final S source);
	
	public default List<T> getTarget(final List<S> source) {
		
		if(source==null) return Collections.emptyList();
		if(source.isEmpty()) return Collections.emptyList();
		
		List<T> target=new ArrayList<T>(source.size());
		for(S _source: source) {
			target.add(getTarget(_source));
		}
		return target;
	}
	
	public default List<S> getSource(final List<T> target) {
		
		if(target==null) return Collections.emptyList();
		if(target.isEmpty()) return Collections.emptyList();
		
		List<S> source=new ArrayList<S>(target.size());
		for(T _target: target) {
			source.add(getSource(_target));
		}
		return source;
	}

}