package com.cox.plm.common.response;
import java.io.Serializable;

public class ActionError implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4874646875004345704L;
	private  String type;
	private  String description;
	private static final String GENERIC = "genericError";

	public ActionError(){
		
	}
	public ActionError(String description) {
		this(GENERIC, description);
	}

	public ActionError(String type, String description) {
		this.type = type;
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public String getDescription() {
		return description;
	}

	@Override
	public String toString() {
		return "ActionError[" + type + ",'" + description + "']";
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
