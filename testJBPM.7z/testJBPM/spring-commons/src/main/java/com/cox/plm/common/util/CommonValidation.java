/**
 * 
 */
package com.cox.plm.common.util;


/**
 * @author nchoube
 *
 */
public final class CommonValidation {
	
	public static boolean validateInputLoginIn(String uname,String pwd){
		
		boolean flag = true;
		
		if(StringUtils.isEmpty(uname) || StringUtils.isEmpty(pwd)){
			flag = false;
		}else if(StringUtils.checkLen(uname.trim(),Constants.LEN_100) || StringUtils.checkLen(pwd.trim(),Constants.LEN_10)){
			flag = false;
		}
		return flag;
	}
}
