/**
 * 
 */
package com.cox.plm.login.dao.services;

import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cox.plm.common.message.handler.MessageHandler;
import com.cox.plm.common.response.ActionResult;
import com.cox.plm.common.util.Constants;
import com.cox.plm.converters.models.PlmUserModel;
import com.cox.plm.login.dao.impl.PlmUserDAOIntf;
import com.cox.plm.login.request.LoginRequest;
import com.cox.plm.login.response.LoginResponse;

/**
 * @author nchoube
 *
 */
@Service
@Transactional
public class PlmUserDAOServices implements PlmUserDAOServiceIntf {

	private static final Logger LOG = Logger.getLogger(PlmUserDAOServices.class);

	@Autowired
	private PlmUserDAOIntf plmUserDAO;

	public LoginResponse validateLoginInUser(LoginRequest loginReq) {

		LOG.info("PlmUserDAOServices - call method validateLoginInUser " + loginReq.getUserName());
		LoginResponse response = new LoginResponse();
		ActionResult actionResult = new ActionResult();
		PlmUserModel plmUserModel = null;
		MessageHandler messageHandler =null;
		String errorMsg ="";

		try {
			
			plmUserModel = plmUserDAO.validateLoginUser(loginReq);
			messageHandler = MessageHandler.getInstance();
			
			if(Objects.isNull(plmUserModel)){
				
				errorMsg = messageHandler.getParameter(Constants.MSG_INVALID_LOGIN, "Either username or password is invalid");
				actionResult.setError(errorMsg);
				response.setActionResult(actionResult);
				response.setActionStatus(Constants.STATUS_FAIL);
				
			}else{
				response.setActionStatus(Constants.STATUS_SUCCESS);
			}
			return response;

		} catch (Exception e) {
			
			LOG.error("PlmUserDAOServices - Exception in validateLoginInUser ", e);
			
			if(!Objects.isNull(messageHandler)){
				
				errorMsg = messageHandler.getParameter(Constants.ERROR_INTERNAL_SERVER, "Internal server error occurred. Please try after sometime");
			}
			actionResult.setError(errorMsg);
			response.setActionResult(actionResult);
			response.setActionStatus(Constants.STATUS_FAIL);
		}
		return response;
	}

}
