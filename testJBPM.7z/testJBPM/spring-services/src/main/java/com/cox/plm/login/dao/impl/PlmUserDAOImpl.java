/**
 * 
 */
package com.cox.plm.login.dao.impl;

import java.io.Serializable;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cox.plm.common.dao.GenericJPADAO;
import com.cox.plm.converters.PlmUserConvertors;
import com.cox.plm.converters.models.PlmUserModel;
import com.cox.plm.entity.pojo.PlmUser;
import com.cox.plm.login.request.LoginRequest;

/**
 * @author nchoube
 *
 */
@Repository
public class PlmUserDAOImpl extends GenericJPADAO<PlmUser, Serializable> implements PlmUserDAOIntf {

	@Autowired
	@Qualifier("plmUserConvertors")
	private PlmUserConvertors plmUserConvertors;

	public PlmUserModel validateLoginUser(LoginRequest loginReq) {

		PlmUser plmUser = getEntityManager().find(PlmUser.class, loginReq.getUserName());

		if (!Objects.isNull(plmUser)) {

			return plmUserConvertors.getTarget(plmUser);
			
		} else {
			return null;
		}
	}

}
