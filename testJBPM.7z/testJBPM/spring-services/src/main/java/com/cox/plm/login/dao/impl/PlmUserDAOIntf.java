/**
 * 
 */
package com.cox.plm.login.dao.impl;

import com.cox.plm.converters.models.PlmUserModel;
import com.cox.plm.login.request.LoginRequest;

/**
 * @author nchoube
 *
 */
public interface PlmUserDAOIntf {
	
	public PlmUserModel validateLoginUser(LoginRequest loginReq);

}
