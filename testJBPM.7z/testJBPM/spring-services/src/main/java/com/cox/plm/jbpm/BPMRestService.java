package com.cox.plm.jbpm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.process.WorkflowProcessInstance;
import org.kie.api.task.TaskService;
import org.kie.api.task.model.TaskSummary;
import org.kie.internal.runtime.manager.context.EmptyContext;
import org.kie.spring.factorybeans.RuntimeManagerFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cox.plm.common.vo.Person;
import com.cox.plm.common.vo.Request;


/*
 * REST API methods to process jBPM tasks
 */


/*
 * Tasks for an user
 */
/*@Path("/json/tasks")
@Transactional*/
@Service
public class BPMRestService {
	
	@Autowired
	@Qualifier("runtimeManager")
	private RuntimeManagerFactoryBean runtimeManager;
	
	/*@POST
	@Path("/pending")
	@Produces(MediaType.APPLICATION_JSON)*/
	public List<TaskData>  getTasks(String user) throws Exception {
		
		KieSession ksession =  ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getKieSession(); //JBPMUtil.getSingletonSession();
        TaskService taskService = ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getTaskService();
        
    	java.util.List<TaskSummary> tasks = taskService.getTasksAssignedAsPotentialOwner(user, "en-UK");
		System.out.println(" Task Data = " + tasks.size());
    	List <TaskData> reqTasks = new ArrayList<TaskData>();
    	TaskData tdata = null;
    	
    	for (int i = 0; i < tasks.size(); i++) {
    		tdata = new TaskData();
    		tdata.setId(tasks.get(i).getId());
    		tdata.setName(tasks.get(i).getName());
    		tdata.setOwner(tasks.get(i).getActualOwner().toString());
    		tdata.setProcessId((tasks.get(i).getProcessInstanceId()));
    		tdata.setStatus(tasks.get(i).getStatus().toString());
    		reqTasks.add(tdata);
    	}
    	
    	return reqTasks;
	}
	
	/*
	 * Paramters for a process ID
	 */
	
	/*@POST
	@Path("/processparams")
	@Produces(MediaType.APPLICATION_JSON)*/
	public Map  getParams(String processId) throws Exception {

		
		KieSession ksession =  ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getKieSession(); //JBPMUtil.getSingletonSession();
        TaskService taskService = ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getTaskService();
		 
         Long procId = new Long((String)processId);
         
         
         WorkflowProcessInstance process = (WorkflowProcessInstance)ksession.getProcessInstance(procId);
		 Map<String, Object> params = new HashMap<String, Object>();
         
			params.put("priority", process.getVariable("priority"));

	        
			params.put("modelNumber", process.getVariable("modelNumber"));
			params.put("quantity",process.getVariable("quantity"));
			
			
 		return params;
	}
	
	
	/*
	 * Complete a task using the paramters taskID, model number etc
	 */
	
	/*@SuppressWarnings("unchecked")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/compleTask")*/
	public List  compleTask(String user,
             String taskId,
             String priority,
             String modelNumber,
             String quantity) throws Exception {
	
		
		   /*UserTransaction ut = (UserTransaction) new InitialContext()
		    .lookup("java:comp/UserTransaction");
             ut.begin();*/
             
		KieSession ksession =  ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getKieSession(); //JBPMUtil.getSingletonSession();
        TaskService taskService = ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getTaskService();
		 
   		    /*
			 * Start a task for user
			 */
		    long tasknum = new Long(taskId).longValue();
			taskService.start(tasknum, user);
			
			/*
			 * complete the task for user
			 */
			
			Map data = new HashMap();
       	    data.put("priority",priority);
       	    data.put("modelNumber",modelNumber);
       	    data.put("quantity",quantity);
			taskService.complete(tasknum, user, data);
	        
	    	java.util.List<TaskSummary> tasks = taskService.getTasksAssignedAsPotentialOwner(user, "en-UK");
	    	
	    	List <TaskData> reqTasks = new ArrayList<TaskData>();
	    	TaskData tdata = null;
	    	
	    	for (int i = 0; i < tasks.size(); i++) {
	    		tdata = new TaskData();
	    		tdata.setId(tasks.get(i).getId());
	    		tdata.setName(tasks.get(i).getName());
	    		tdata.setOwner(tasks.get(i).getActualOwner().toString());
	    		tdata.setProcessId((tasks.get(i).getProcessInstanceId()));
	    		tdata.setStatus(tasks.get(i).getStatus().toString());
	    		reqTasks.add(tdata);
	    	}
	      
	    	
	    	//ut.commit();
 		return reqTasks;
	}
	
	/*
	 * Create a process with a given parameters
	 */
	
	/*@POST
	@Produces("text/plain")
	@Path("/createProcess")*/
	public String  createProcess() throws Exception  {
		
		KieSession ksession =  ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getKieSession(); //JBPMUtil.getSingletonSession();
        TaskService taskService = ((RuntimeManager)runtimeManager.getObject()).getRuntimeEngine(EmptyContext.get()).getTaskService();

        Person person = new Person("johny", "John Doe");
		person.setAge(20);
		Request request = new Request("12345");
		request.setPersonId("john");
		request.setAmount(1000L);
		ksession.insert(person);
		ksession.insert(request);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("request", request);
		WorkflowProcessInstance processInstance = (WorkflowProcessInstance) ksession.startProcess("com.sample.bpmn.plm", params);
		ksession.insert(processInstance);
		ksession.fireAllRules();

			//ksession.startProcess("com.sample.bpmn.sampleHTformvariables",
				//	params);
			System.out.println(" after start !!! ");
			// ksession.fireAllRules();
			//ut.commit();
		
		return Boolean.toString(true);
	}
	
}
