package com.cox.plm.common.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.orm.jpa.persistenceunit.MutablePersistenceUnitInfo;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;

import net.sourceforge.stripes.util.ResolverUtil;

/**
 * This PersistenceUnitPostProcessor is used to search given package list for
 * JPA entities and add them as managed entities. By default the JPA engine
 * searches for persistent classes only in the same class-path of the location
 * of the persistence.xml file. When running unit tests the entities end up in
 * test-classes folder which does not get scanned. To avoid specifying each
 * entity in the persistence.xml file to scan, this post processor automatically
 * adds the entities for you.
 *
 */
public class CustomPersistenceUnitPostProcessor implements PersistenceUnitPostProcessor, InitializingBean {

    private static final Logger LOG = LogManager.getLogger(CustomPersistenceUnitPostProcessor.class);

    /**
     * the path of packages to search for persistent classes (e.g.
     * org.springframework). Subpackages will be visited, too
     */
    private List<String> packages;

    /** the calculated list of additional persistent classes */
    private Set<Class<? extends Object>> persistentClasses;

    /**
     * Looks for any persistent class in the class-path under the specified
     * packages
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (packages == null || packages.isEmpty())
            throw new IllegalArgumentException("packages property must be set");
        LOG.debug("Looking for @Entity in " + packages);
        persistentClasses = new HashSet<>();
        for (String p : packages) {
            ResolverUtil<Object> resolver = new ResolverUtil<>();
            ClassLoader cl = this.getClass().getClassLoader();
            LOG.debug("Using classloader: " + cl);
            resolver.setClassLoader(cl);
            resolver.findAnnotated(Entity.class, p);
            Set<Class<? extends Object>> classes = resolver.getClasses();
            LOG.debug("Annotated classes:  " + classes);
            persistentClasses.addAll(classes);
        }
        if (persistentClasses.isEmpty())
            throw new IllegalArgumentException("No class annotated with @Entity found in: " + packages);
    }

    /**
     * Add all the persistent classes found to the PersistentUnit
     */
    @Override
    public void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo persistenceUnitInfo) {
        for (Class<? extends Object> c : persistentClasses)
            persistenceUnitInfo.addManagedClassName(c.getName());
    }

    public void setPackages(List<String> packages) {
        this.packages = packages;
    }
}
