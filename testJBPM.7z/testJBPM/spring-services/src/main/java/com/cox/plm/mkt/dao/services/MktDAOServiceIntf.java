/**
 * 
 */
package com.cox.plm.mkt.dao.services;

import java.util.List;

import com.cox.plm.mkt.request.MktNewProReq;
import com.cox.plm.mkt.response.MktNewProjResp;

/**
 * @author nchoube
 *
 */
public interface MktDAOServiceIntf {
	
	public MktNewProjResp createProject(MktNewProReq mktNewProReq);
	public List<MktNewProjResp> fetchAllProjects();

}
