/**
 * 
 */
package com.cox.plm.mkt.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cox.plm.common.dao.GenericJPADAO;
import com.cox.plm.converters.ProjectMasterConvertors;
import com.cox.plm.converters.models.ProjectMasterModel;
import com.cox.plm.entity.pojo.ProcessMaster;
import com.cox.plm.entity.pojo.ProjectMaster;

/**
 * @author nchoube
 *
 */
@Repository
public class MktDAOImpl extends GenericJPADAO<ProjectMaster, Serializable> implements MktDAOIntf {

	private static final Logger LOG = Logger.getLogger(MktDAOImpl.class);
	
	@Autowired
	@Qualifier("projectMasterConvertors")
	private ProjectMasterConvertors projMasterConvertors;
	
	@Override
	public boolean createNewProject(ProjectMasterModel projMasterModel) {
		
		try {
			
			ProjectMaster projMaster = projMasterConvertors.getSource(projMasterModel);
			persistProcessMaster(projMaster);
			return true;
		} catch (Exception e) {
			LOG.error("MktDAOImpl - Exception in createNewProject ",e);
			return false;
		}
		
	}
	
	

	@Override
	public ProcessMaster findProcessId(ProjectMaster projMaster) {
		/*try {
			
			//getEntityManager().find(ProjectMaster.class, "");
			return null;
		} catch (Exception e) {
			LOG.error("MktDAOImpl - Exception in createNewProject ",e);
			return null;
		}*/
		return null;
	}

	@Override
	public void persistProcessMaster(ProjectMaster projMaster) {
		
		javax.persistence.Query query = getEntityManager().createNativeQuery("INSERT INTO PROJECT_MASTER (PROJECT_ID,PROJECT_CODE,PROJECT_TYPE,PROJECT_NAME,PROJECT_DESC,PROJECT_START_DATE,PROJECT_END_DATE) VALUES(?,?,?,?,?,?,?)");
		
	    query.setParameter(1, projMaster.getProjectId());
        query.setParameter(2, projMaster.getProjectCode());
        query.setParameter(3, projMaster.getProjectType());
        query.setParameter(4, projMaster.getProjectName());
        query.setParameter(5, projMaster.getProjectDesc());
        query.setParameter(6, projMaster.getProjectStartDt());
        query.setParameter(7, projMaster.getProjectEndDt());
       
       int i = query.executeUpdate();
       LOG.info("Record inserted ="+i);
	}



	@Override
	public List<ProjectMasterModel> fetchAllProjects() {
		
		javax.persistence.Query query = getEntityManager().createNamedQuery("ProjectMaster.ALLPROJECT");
		List<ProjectMaster> listProjectMaster= query.getResultList();
		List<ProjectMasterModel> projMasterModelList = projMasterConvertors.getTarget(listProjectMaster);
		return projMasterModelList;
	}

}
