/**
 * 
 */
package com.cox.plm.mkt.dao.impl;

import java.util.List;

import com.cox.plm.converters.models.ProjectMasterModel;
import com.cox.plm.entity.pojo.ProcessMaster;
import com.cox.plm.entity.pojo.ProjectMaster;

/**
 * @author nchoube
 *
 */
public interface MktDAOIntf {
	
	public boolean createNewProject(ProjectMasterModel projMasterModel);
	public ProcessMaster findProcessId(ProjectMaster projMaster);
	public void persistProcessMaster(ProjectMaster projMaster);
	public List<ProjectMasterModel> fetchAllProjects();

}
