package com.cox.plm.common.dao;

/**
 * JPA implementation of the GenericDao.
 * 
 * 
 * @param <T>
 *            The persistent type
 * @param <ID>
 *            The primary key type
 */

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

/**
 * JPA implementation of the GenericDao.
 * 
 * 
 * @param <T>
 *            The persistent type
 * @param <I>
 *            The primary key type
 */

@Repository
public abstract class GenericJPADAO<T, I extends Serializable> implements GenericJPADAOIntf<T, I> {

    private final Class<T> persistentClass;
    @PersistenceContext
    EntityManager entityManager;

    final String simpleName;

    @SuppressWarnings("unchecked")
    public GenericJPADAO() {
        this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass())
                .getActualTypeArguments()[0];
        simpleName = getEntityClass().getSimpleName();
    }

    public GenericJPADAO(final Class<T> persistentClass) {
        super();
        this.persistentClass = persistentClass;
        simpleName = getEntityClass().getSimpleName();
    }

    /**
     * set the JPA entity manager to use.
     * 
     * @param entityManager
     */

    @Override
    public EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    public Class<T> getEntityClass() {
        return persistentClass;
    }

    @Override
    public T findById(final I id) {
        return getEntityManager().find(persistentClass, id);
    }

    @Override
    public List<T> findAll() {
        return Collections.emptyList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByNamedQuery(final String name, Object... params) {
        javax.persistence.Query query = getEntityManager().createNamedQuery(name);

        for (int i = 0; i < params.length; i++) {
            query.setParameter(i + 1, params[i]);
        }
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByNamedQueryAndNamedParams(final String name, final Map<String, ? extends Object> params) {
        javax.persistence.Query query = getEntityManager().createNamedQuery(name);

        for (final Map.Entry<String, ? extends Object> param : params.entrySet()) {
            query.setParameter(param.getKey(), param.getValue());
        }

        return query.getResultList();
    }

    /**
     * @Override public void deleteByNamedQueryAndNamedParams(final String name,
     *           final Map<String, ? extends Object> params) {
     *           javax.persistence.Query query =
     *           getEntityManager().createNamedQuery(name);
     * 
     *           for (final Map.Entry<String, ? extends Object> param :
     *           params.entrySet()) { query.setParameter(param.getKey(),
     *           param.getValue()); } query.executeUpdate(); }
     */
    /**
     * to merge the entity
     * 
     * @return merged entity
     */
    @Override
    public T save(T entity) {
        return getEntityManager().merge(entity);
    }

    /**
     * to persist the entity
     * 
     * @return same entity
     */
    @Override
    public T savePersist(T entity) {
        getEntityManager().persist(entity);
        return entity;
    }

    /**
     * @Override public void delete(T entity) {
     *           getEntityManager().remove(entity); }
     */
    /**
     * @Override public void deleteById(final I id) {
     *           getEntityManager().remove(findById(id)); }
     */
    @Override
    public void flush() {
        entityManager.flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByNamedQueryWithoutArguments(final String queryName) {
        return getEntityManager().createNamedQuery(queryName).getResultList();
    }
}
