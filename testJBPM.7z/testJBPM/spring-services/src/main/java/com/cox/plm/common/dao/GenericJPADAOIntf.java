package com.cox.plm.common.dao;

/*
 * Generic DAO interface providing basic CRUD operations
 * 
 * @param <T> the entity type
 * @param <ID> the primary key type
 * 
 */

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

public interface GenericJPADAOIntf<T, I extends Serializable> {

    /**
     * Get the Class of the entity
     *
     * @return the class
     */
    Class<T> getEntityClass();

    /**
     * Find an entity by its primary key
     *
     * @param id
     *            the primary key
     * @return the entity
     */
    T findById(final I id);

    /**
     * Load all entities
     *
     * @return the list of entities
     */
    List<T> findAll();

    /**
     * Find using a named query
     *
     * @param queryName
     *            the name of the query
     * @param params
     *            the query parameters
     *
     * @return the list of entities
     */
    List<T> findByNamedQuery(final String queryName, Object... params);

    /**
     * Find using a named query
     *
     * @param queryName
     *            the name of the query
     * @param params
     *            the query parameters
     *
     * @return the list of entities
     */
    List<T> findByNamedQueryAndNamedParams(final String queryName, final Map<String, ? extends Object> params);

    /**
     * save an entity. This can be either a INSERT or UPDATE in the database
     * 
     * @param entity
     *            the entity to save
     * 
     * @return the saved entity
     */
    T save(final T entity);

    /**
     * delete an entity from the database
     * 
     * @param entity
     *            the entity to delete
     */
  /**   void delete(final T entity);
  */
    /**
     * delete an entity by ID from the database
     * 
     * @param id
     *            the primary key
     */
    
   /** void deleteById(final I id);**/

    /**
     * flush entities to the database
     * 
     */
    void flush();

    /**
     * 
     * @param name
     * @param params
     */
    /**public void deleteByNamedQueryAndNamedParams(final String name, final Map<String, ? extends Object> params);**/

    /**
     * 
     * @return
     */
    public EntityManager getEntityManager();

    /**
     * 
     * @param queryName
     * @return
     */
    List<T> findByNamedQueryWithoutArguments(final String queryName);

    /**
     * 
     * @param name
     * @param params
     * @return
     */
   /** int deleteByParams(String name, Map<String, ? extends Object> params);**/

    /**
     * 
     * @param entity
     * @return
     */
    public T savePersist(T entity);

}
