/**
 * 
 */
package com.cox.plm.mkt.dao.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cox.plm.common.util.Constants;
import com.cox.plm.converters.models.ProjectMasterModel;
import com.cox.plm.jbpm.BPMRestService;
import com.cox.plm.mkt.dao.impl.MktDAOIntf;
import com.cox.plm.mkt.request.MktNewProReq;
import com.cox.plm.mkt.response.MktNewProjResp;

/**
 * @author nchoube
 *
 */
@Service
public class MktDAOServices implements MktDAOServiceIntf {

	private static final Logger LOG = Logger.getLogger(MktDAOServices.class);
	
	@Autowired
	private MktDAOIntf mktDAOIntf;
	
	@Autowired
	private BPMRestService restService;
	
	@Override
	@Transactional
	public MktNewProjResp createProject(MktNewProReq mktNewProReq) {
		
		MktNewProjResp resp = new MktNewProjResp();
		
		try {
			
			ProjectMasterModel projMasterModel = new ProjectMasterModel();
			projMasterModel.setProjectId(Constants.PROCESS_ID_MARKETING);
			projMasterModel.setProjectCode(mktNewProReq.getProjectCode());
			//projMasterModel.setProjectCode(Constants.PROJECT_CODE_MARKETING);
			projMasterModel.setProjectName(mktNewProReq.getProjectName());
			projMasterModel.setProjectType(mktNewProReq.getProjectType());
			projMasterModel.setProjectDesc(mktNewProReq.getProjectDesc());
			projMasterModel.setProjectStartDt(mktNewProReq.getProjectStartDt());
			projMasterModel.setProjectEndDt(mktNewProReq.getProjectEndDt());
			
			 boolean flag = mktDAOIntf.createNewProject(projMasterModel);
			 
			 if(flag){
				 resp.setActionStatus(Constants.STATUS_SUCCESS);
			 }else{
				 resp.setActionStatus(Constants.STATUS_FAIL);
			 }
			
			 //BPMRestService bpm = new BPMRestService();
			 restService.createProcess();
			 //BPMRestService.createProcess();
			 
			return resp;
			
		} catch (Exception e) {
			LOG.error("MktDAOServices - Exception in createProject method ",e);
			resp.setActionStatus(Constants.STATUS_FAIL);
		}
		
		return resp;
	}

	@Override
	public List<MktNewProjResp> fetchAllProjects() {
		
		List<MktNewProjResp> mktRespList = new ArrayList<MktNewProjResp>();
		
		try {
			
			List<ProjectMasterModel> projMasterModelList = mktDAOIntf.fetchAllProjects();
			
			for(ProjectMasterModel projectMasterModel : projMasterModelList){
				
				MktNewProjResp mktResp = new MktNewProjResp();
				
				mktResp.setProjectCode(projectMasterModel.getProjectCode());
				mktResp.setProjectName(projectMasterModel.getProjectName());
				mktResp.setProjectType(projectMasterModel.getProjectType());
				mktResp.setProjectDesc(projectMasterModel.getProjectDesc());
				mktResp.setProjectStartDt(projectMasterModel.getProjectStartDt());
				mktResp.setProjectEndDt(projectMasterModel.getProjectEndDt());
				
				mktRespList.add(mktResp);
			}
			return mktRespList;
			
		} catch (Exception e) {
			LOG.error("MktDAOServices - Exception in fetchAllProjects method ",e);
		}
		return mktRespList;		
	}

}
