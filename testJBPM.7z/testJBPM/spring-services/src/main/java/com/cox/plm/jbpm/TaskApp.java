package com.cox.plm.jbpm;

import java.util.HashSet;
import java.util.Set;

public class TaskApp /*extends Application*/ {

	public Set<Class<?>> getClasses()
    {
        Set<Class<?>> s = new HashSet<Class<?>>();
        s.add(BPMRestService.class);
        return s;
    }
}
