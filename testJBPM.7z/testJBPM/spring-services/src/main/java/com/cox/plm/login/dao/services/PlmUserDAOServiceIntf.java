/**
 * 
 */
package com.cox.plm.login.dao.services;

import com.cox.plm.login.request.LoginRequest;
import com.cox.plm.login.response.LoginResponse;

/**
 * @author nchoube
 *
 */
public interface PlmUserDAOServiceIntf {
	
	public LoginResponse validateLoginInUser(LoginRequest loginReq);

}
